
# Clube Prime Plus Life

Projeto React/Vite para consulta de membros do Clube Prime.

## Como usar

1. Suba na Vercel
2. Conecte o domínio:
membrosclubeprime.pluslifeacademia.com.br

## Planilha conectada
A página já está integrada ao Google Sheets.
